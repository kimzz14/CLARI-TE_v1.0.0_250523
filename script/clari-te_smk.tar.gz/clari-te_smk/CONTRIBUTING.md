Pauline LASSERRE-ZUBER <pauline.lasserre-zuber@inrae.fr>
Josquin DARON <josquin.daron@pasteur.fr>
Frederic CHOULET <frederic.choulet@inrae.fr>
UMR 1095 INRAE UCA [GDEC](https://umr1095.clermont.hub.inrae.fr/)
